# This program demonstrates the break statement with a for loop.
for n in range(100):
    print(n)
    if n == 5:
        break

print(f'The loop stopped and n is {n}.')
