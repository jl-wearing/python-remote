n = 100
while n < 5:
    print(n)
    n += 1
else:
    print(f'Now n is {n}.')
