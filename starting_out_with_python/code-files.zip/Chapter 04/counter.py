# This program demonstrates a count-controlled while loop.

n = 0
while n < 5:
    print(f'Inside the loop, the value of n is {n}.')
    n += 1
