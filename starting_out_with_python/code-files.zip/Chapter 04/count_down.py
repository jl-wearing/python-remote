# This program displays a count-down.

print('Beginning countdown.')

count = 10
while count > 0:
    print(count)
    count -= 1

print('Blastoff!')