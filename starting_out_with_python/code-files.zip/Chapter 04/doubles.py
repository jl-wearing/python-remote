# This program demonstrates a count-controlled while loop.

number = 1
while number <= 10:
    print(f'{number} plus {number} is {number + number}')
    number += 1
