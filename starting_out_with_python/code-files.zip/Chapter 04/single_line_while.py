# This program demonstrates a single-line while statement.

n = 0
while n < 10: n += 1
print(f'After the loop, n is {n}.')
